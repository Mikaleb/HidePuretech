import{i as y}from"./initialState-KfCBLEww.js";const h="lcm-disabled",x="lcm-loading-spinner",C="lcm-hide-completely",d="lcm-hidden-placeholder",p="lcm-rehide-btn",T="lcm-style";function W(t){if(document.getElementById(T)){const e=document.getElementById(T);e&&e.remove()}const i=document.createElement("style");if(i.id=T,i.textContent=`
    .${h}, [data-lcm-disabled="true"] {
      opacity: 0.35 !important;
      filter: grayscale(100%) !important;
      pointer-events: none !important;
    }
    .${h} *, [data-lcm-disabled="true"] * {
      text-decoration: line-through !important;
    }
  `,t&&(i.textContent+=`
      .${C}:not([data-lcm-user-show="true"]) {
        display: none !important;
      }
    `),i.textContent+=`
    .${d} {
      display: flex !important;
      align-items: center !important;
      height: 28px !important;
      padding: 0 12px !important;
      margin: 8px 0 !important;
      background: rgba(242, 69, 53, 0.03) !important;
      border: 1px dashed rgba(242, 69, 53, 0.3) !important;
      border-radius: 6px !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
      color: #666 !important;
      font-size: 11px !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      user-select: none !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .${d}:hover {
      background: rgba(242, 69, 53, 0.08) !important;
      border-color: rgba(242, 69, 53, 0.5) !important;
    }
    .${d} img {
      width: 14px !important;
      height: 14px !important;
      margin-right: 8px !important;
      opacity: 0.7 !important;
    }
    .lcm-placeholder-line {
      flex-grow: 1 !important;
      height: 1px !important;
      background: linear-gradient(90deg, rgba(242, 69, 53, 0.2) 0%, rgba(242, 69, 53, 0) 100%) !important;
      margin: 0 12px !important;
    }
    .lcm-placeholder-btn {
      color: #f24535 !important;
      font-weight: 600 !important;
      text-transform: uppercase !important;
      letter-spacing: 0.5px !important;
      font-size: 10px !important;
      padding: 2px 6px !important;
      border-radius: 4px !important;
    }
    .lcm-placeholder-btn:hover {
      background: rgba(242, 69, 53, 0.1) !important;
    }
    .${p} {
      position: absolute !important;
      top: 8px !important;
      right: 8px !important;
      z-index: 9999 !important;
      background: #f24535 !important;
      color: white !important;
      padding: 4px 12px !important;
      border-radius: 6px !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      cursor: pointer !important;
      border: none !important;
      box-shadow: 0 4px 12px rgba(242, 69, 53, 0.3) !important;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
      opacity: 0 !important;
      pointer-events: none !important;
      text-transform: uppercase !important;
      letter-spacing: 0.5px !important;
    }
    /* Revealed state aesthetic */
    [data-lcm-user-show="true"] {
      position: relative !important;
      opacity: 0.8 !important;
      filter: grayscale(30%) !important;
      background: rgba(242, 69, 53, 0.04) !important;
      border: 2px dashed rgba(242, 69, 53, 0.3) !important;
      border-radius: 12px !important;
      pointer-events: auto !important;
      transition: all 0.3s ease !important;
    }
    [data-lcm-user-show="true"] * {
      text-decoration: none !important;
    }
    [data-lcm-user-show="true"] .${p} {
      opacity: 0.7 !important;
      pointer-events: auto !important;
    }
    [data-lcm-user-show="true"]:hover .${p} {
      opacity: 1 !important;
    }
    .${p}:hover {
      background: #d43224 !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 6px 16px rgba(242, 69, 53, 0.4) !important;
    }
    #${x} {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 24px;
      height: 24px;
      border: 3px solid rgba(0,0,0,0.1);
      border-radius: 50%;
      border-top-color: #3498db;
      animation: lcm-spin 0.8s linear infinite;
      z-index: 999999;
      pointer-events: none;
      background: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      display: none;
    }
    @keyframes lcm-spin {
      to { transform: rotate(360deg); }
    }
  `,document.head.appendChild(i),!document.getElementById(x)){const e=document.createElement("div");e.id=x,document.body.appendChild(e)}}function D(){const t=document.getElementById(x);t&&(t.style.display="block")}function V(){const t=document.getElementById(x);t&&(t.style.display="none")}var s=(t=>(t.LeBonCoin="LeBonCoin",t.AutoSphere="AutoSphere",t.LaCentrale="LaCentrale",t.AramisAuto="AramisAuto",t.AutoScout24="AutoScout24",t))(s||{});class w{constructor(i,e=[],r=[],o=""){switch(this.name=i,this.parentClasses=e,this.adClasses=r,this.titleSelector=o,i){case s.LeBonCoin:this.parentClasses=["li"],this.adClasses=['[data-test-id="adcard-title"]',"a","article"],this.titleSelector='[data-test-id="adcard-title"]';break;case s.LaCentrale:this.parentClasses=["searchCard","listingContainer","searchCardContainer"],this.adClasses=['[data-testid*="vehicleCard"]',"lien-fiche","link_veh"],this.titleSelector='h2[class*="title"], h2[class*="vehiclecardV2_title"], h3[class*="title"], [class*="searchCard__title"]';break;case s.AutoSphere:this.parentClasses=["thumbnail_vehicle","fiche-synth"],this.titleSelector=".title, h2, h3";break;case s.AramisAuto:this.parentClasses=["vehicle-card"],this.titleSelector=".vehicle-card__title, h3";break;case s.AutoScout24:this.parentClasses=["article.list-item",".list-item","article"],this.adClasses=["article","a"],this.titleSelector="h2";break;default:this.parentClasses=[],this.adClasses=[],this.titleSelector=""}}}function U(t){return t.includes("lacentrale")?new w(s.LaCentrale):t.includes("aramisauto")?new w(s.AramisAuto):t.includes("leboncoin")?new w(s.LeBonCoin):t.includes("autosphere")?new w(s.AutoSphere):t.includes("autoscout24")?new w(s.AutoScout24):new w(s.LaCentrale)}function z(t,i){if(t.parentClasses.length===0)return null;const e=t.parentClasses.map(r=>r.startsWith("[")||r.includes(":")||r==="li"||r==="article"?r:`.${r}`).join(", ");return i.closest(e)}function H(t,i,e,r){var A,S,m,L;const o=z(t,i)||i;if(!e){(A=o.previousElementSibling)!=null&&A.classList.contains(d)&&o.previousElementSibling.remove();const n=o.querySelector(`.${p}`);n&&n.remove()}if(o.getAttribute("data-lcm-user-show")==="true"){if(o.classList.add(h),o.classList.remove(C),o.setAttribute("data-lcm-disabled","true"),(S=o.previousElementSibling)!=null&&S.classList.contains(d)&&o.previousElementSibling.remove(),!o.querySelector(`.${p}`)){const n=document.createElement("button");n.className=p,n.textContent="Hide ad",n.onclick=u=>{u.preventDefault(),u.stopPropagation(),o.removeAttribute("data-lcm-user-show"),o.classList.add(C),H(t,i,e,r)},o.appendChild(n)}return}if(i.classList.add(h),i.setAttribute("data-lcm-disabled","true"),o.classList.add(h),o.setAttribute("data-lcm-disabled","true"),e&&(o.classList.add(C),!((m=o.previousElementSibling)!=null&&m.classList.contains(d)))){const n=document.createElement("div");n.className=d;const u=typeof chrome<"u"&&chrome.runtime?chrome.runtime.getURL("public/favicon-16x16.png"):"";let b="Vehicle";if(t.titleSelector){const l=o.querySelector(t.titleSelector);l&&l.textContent&&(b=l.textContent.trim().split(`
`)[0])}const f=o.getAttribute("data-lcm-motor")||"",a=b!=="Vehicle"?`${b}${f?` (${f})`:""}`:`${f||"Ad"} hidden`;n.innerHTML=`
        ${r?`<img src="${u}" alt="icon">`:""}
        <span>${a}</span>
        <div class="lcm-placeholder-line"></div>
        <div class="lcm-placeholder-btn">Show</div>
      `,n.onclick=l=>{l.stopPropagation(),o.setAttribute("data-lcm-user-show","true"),o.classList.remove(C),n.remove()},(L=o.parentNode)==null||L.insertBefore(n,o)}}function F(t,i){var o;i.classList.remove(h),i.removeAttribute("data-lcm-disabled"),i.removeAttribute("data-lcm-user-show");const e=z(t,i)||i;e.classList.remove(h),e.classList.remove(C),e.removeAttribute("data-lcm-disabled"),e.removeAttribute("data-lcm-user-show"),(o=e.previousElementSibling)!=null&&o.classList.contains(d)&&e.previousElementSibling.remove();const r=e.querySelector(`.${p}`);r&&r.remove()}let q=0,B=null,R=null;async function j(t,i,e,r){const o=++q;W(e),D(),(B!==null&&B!==e||R!==null&&R!==r)&&(document.querySelectorAll(`.${d}`).forEach(a=>a.remove()),B!==e&&document.querySelectorAll("[data-lcm-user-show]").forEach(a=>a.removeAttribute("data-lcm-user-show"))),B=e,R=r;const A=i.map(a=>new RegExp(a.pattern,"i")),S=a=>A.some(l=>l.test(a)),m=U(window.location.href),L=m.adClasses.length>0?m.adClasses.map(a=>a.startsWith("[")||a.includes(":")||a==="article"||a==="a"?a:`.${a}`).join(", "):"a",n=Array.from(document.querySelectorAll(L)),u=new Set;n.forEach(a=>{const l=z(m,a);l&&u.add(l)});const b=Array.from(u),f=50;for(let a=0;a<b.length;a+=f){if(o!==q)return;b.slice(a,a+f).forEach(c=>{let E=(c.textContent||"")+" "+(c.getAttribute("aria-label")||"")+" "+(c.getAttribute("title")||"")+" "+(c.getAttribute("alt")||"");if(c.querySelectorAll("[aria-label], [title], [alt]").forEach(g=>{E+=" "+(g.getAttribute("aria-label")||"")+" "+(g.getAttribute("title")||"")+" "+(g.getAttribute("alt")||"")}),t&&E&&S(E)){const g=i.find(N=>new RegExp(N.pattern,"i").test(E));g&&c.setAttribute("data-lcm-motor",g.title),H(m,c,e,r)}else F(m,c)}),await new Promise(c=>requestAnimationFrame(c))}o===q&&V()}const O=location.href;let v=y.websites,k=y.motors,_=y.hideCompletely,I=y.showPlaceholderIcon,M=y.showBadgeCount;function Y(t,i){const e=r=>new RegExp("^"+r.replace(/\*/g,".*").replace(/\?/g,".")+"$");return t.find(r=>e(r.url).test(i))}const P=async()=>{const t=Y(v,O);if(!t)return;const i=t.active?k.filter(r=>r.active):[];await j(t.active&&i.length>0,i,_,I);const e=document.querySelectorAll('[data-lcm-disabled="true"]').length;browser.runtime.sendMessage({action:"updateBadge",count:e,showBadgeCount:M}).catch(()=>{})},J=K(P,300);let $=null;function G(){$&&$.disconnect(),$=new MutationObserver(J),$.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-lcm-disabled","aria-label","title","alt"]})}browser.runtime.onMessage.addListener((t,i,e)=>{if(t.websites)if(Array.isArray(t.websites)&&t.websites.length===1){const r=t.websites[0];v=v.map(o=>o.title===r.title?r:o)}else Array.isArray(t.websites)&&(v=t.websites);if(t.motors&&(k=t.motors),t.hideCompletely!==void 0&&(_=t.hideCompletely),t.showPlaceholderIcon!==void 0&&(I=t.showPlaceholderIcon),t.showBadgeCount!==void 0&&(M=t.showBadgeCount),t.action==="getHiddenCount"){const r=document.querySelectorAll('[data-lcm-disabled="true"]').length;e({status:"received",count:r});return}P(),e({status:"received"})});browser.storage.onChanged.addListener((t,i)=>{i==="sync"&&(t.websites&&(v=t.websites.newValue),t.motors&&(k=t.motors.newValue),t.hideCompletely&&(_=t.hideCompletely.newValue),t.showPlaceholderIcon&&(I=t.showPlaceholderIcon.newValue),t.showBadgeCount&&(M=t.showBadgeCount.newValue),P())});function K(t,i){let e=null;return(...r)=>{e&&clearTimeout(e),e=window.setTimeout(()=>t(...r),i)}}function Q(){browser.storage.sync.get(["websites","motors","hideCompletely","showPlaceholderIcon","showBadgeCount"],t=>{t.websites&&(v=t.websites),t.motors&&(k=t.motors),t.hideCompletely!==void 0&&(_=t.hideCompletely),t.showPlaceholderIcon!==void 0&&(I=t.showPlaceholderIcon),t.showBadgeCount!==void 0&&(M=t.showBadgeCount),P(),G()})}Q();
