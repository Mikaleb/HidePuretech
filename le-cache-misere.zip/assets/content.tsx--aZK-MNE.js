import{i as L}from"./initialState-C4rzyktb.js";const f="lcm-disabled",E="lcm-loading-spinner",v="lcm-hide-completely",d="lcm-hidden-placeholder",b="lcm-rehide-btn",N="lcm-style";function U(t){if(document.getElementById(N)){const e=document.getElementById(N);e&&e.remove()}const i=document.createElement("style");if(i.id=N,i.textContent=`
    .${f}, [data-lcm-disabled="true"] {
      opacity: 0.35 !important;
      filter: grayscale(100%) !important;
      pointer-events: none !important;
    }
    .${f} *, [data-lcm-disabled="true"] * {
      text-decoration: line-through !important;
    }
  `,t&&(i.textContent+=`
      .${v}:not([data-lcm-user-show="true"]) {
        display: none !important;
      }
    `),i.textContent+=`
    .${d} {
      display: flex !important;
      align-items: center !important;
      height: 28px !important;
      padding: 0 12px !important;
      margin: 8px 0 !important;
      background: rgba(242, 69, 53, 0.03) !important;
      border: 1px dashed rgba(242, 69, 53, 0.3) !important;
      border-radius: 6px !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
      color: #666 !important;
      font-size: 11px !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      user-select: none !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .${d}:hover {
      background: rgba(242, 69, 53, 0.08) !important;
      border-color: rgba(242, 69, 53, 0.5) !important;
    }
    .${d} img {
      width: 14px !important;
      height: 14px !important;
      margin-right: 8px !important;
      opacity: 0.7 !important;
    }
    .lcm-placeholder-line {
      flex-grow: 1 !important;
      height: 1px !important;
      background: linear-gradient(90deg, rgba(242, 69, 53, 0.2) 0%, rgba(242, 69, 53, 0) 100%) !important;
      margin: 0 12px !important;
    }
    .lcm-placeholder-btn {
      color: #f24535 !important;
      font-weight: 600 !important;
      text-transform: uppercase !important;
      letter-spacing: 0.5px !important;
      font-size: 10px !important;
      padding: 2px 6px !important;
      border-radius: 4px !important;
    }
    .lcm-placeholder-btn:hover {
      background: rgba(242, 69, 53, 0.1) !important;
    }
    .${b} {
      position: absolute !important;
      top: 8px !important;
      right: 8px !important;
      z-index: 9999 !important;
      background: #f24535 !important;
      color: white !important;
      padding: 4px 12px !important;
      border-radius: 6px !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      cursor: pointer !important;
      border: none !important;
      box-shadow: 0 4px 12px rgba(242, 69, 53, 0.3) !important;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
      opacity: 0 !important;
      pointer-events: none !important;
      text-transform: uppercase !important;
      letter-spacing: 0.5px !important;
    }
    /* Revealed state aesthetic */
    [data-lcm-user-show="true"] {
      position: relative !important;
      opacity: 0.8 !important;
      filter: grayscale(30%) !important;
      background: rgba(242, 69, 53, 0.04) !important;
      border: 2px dashed rgba(242, 69, 53, 0.3) !important;
      border-radius: 12px !important;
      pointer-events: auto !important;
      transition: all 0.3s ease !important;
    }
    [data-lcm-user-show="true"] * {
      text-decoration: none !important;
    }
    [data-lcm-user-show="true"] .${b} {
      opacity: 0.7 !important;
      pointer-events: auto !important;
    }
    [data-lcm-user-show="true"]:hover .${b} {
      opacity: 1 !important;
    }
    .${b}:hover {
      background: #d43224 !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 6px 16px rgba(242, 69, 53, 0.4) !important;
    }
    #${E} {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 24px;
      height: 24px;
      border: 3px solid rgba(0,0,0,0.1);
      border-radius: 50%;
      border-top-color: #3498db;
      animation: lcm-spin 0.8s linear infinite;
      z-index: 999999;
      pointer-events: none;
      background: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      display: none;
    }
    @keyframes lcm-spin {
      to { transform: rotate(360deg); }
    }
  `,document.head.appendChild(i),!document.getElementById(E)){const e=document.createElement("div");e.id=E,document.body.appendChild(e)}}function F(){const t=document.getElementById(E);t&&(t.style.display="block")}function j(){const t=document.getElementById(E);t&&(t.style.display="none")}var l=(t=>(t.LeBonCoin="LeBonCoin",t.AutoSphere="AutoSphere",t.LaCentrale="LaCentrale",t.AramisAuto="AramisAuto",t.AutoScout24="AutoScout24",t))(l||{});class x{constructor(i,e=[],n=[],o=""){switch(this.name=i,this.parentClasses=e,this.adClasses=n,this.titleSelector=o,i){case l.LeBonCoin:this.parentClasses=["li"],this.adClasses=['[data-test-id="adcard-title"]',"a","article"],this.titleSelector='[data-test-id="adcard-title"]';break;case l.LaCentrale:this.parentClasses=["searchCard","listingContainer","searchCardContainer"],this.adClasses=['[data-testid*="vehicleCard"]',"lien-fiche","link_veh"],this.titleSelector='h2[class*="title"], h2[class*="vehiclecardV2_title"], h3[class*="title"], [class*="searchCard__title"]';break;case l.AutoSphere:this.parentClasses=["thumbnail_vehicle","fiche-synth"],this.titleSelector=".title, h2, h3";break;case l.AramisAuto:this.parentClasses=["vehicle-card"],this.titleSelector=".vehicle-card__title, h3";break;case l.AutoScout24:this.parentClasses=["article.list-item",".list-item","article"],this.adClasses=["article","a"],this.titleSelector="h2";break;default:this.parentClasses=[],this.adClasses=[],this.titleSelector=""}}}function O(t){return t.includes("lacentrale")?new x(l.LaCentrale):t.includes("aramisauto")?new x(l.AramisAuto):t.includes("leboncoin")?new x(l.LeBonCoin):t.includes("autosphere")?new x(l.AutoSphere):t.includes("autoscout24")?new x(l.AutoScout24):new x(l.LaCentrale)}function V(t,i){if(t.parentClasses.length===0)return null;const e=t.parentClasses.map(n=>n.startsWith("[")||n.includes(":")||n==="li"||n==="article"?n:`.${n}`).join(", ");return i.closest(e)}function W(t,i,e,n){var B,$,m,k;const o=V(t,i)||i;if(!e){(B=o.previousElementSibling)!=null&&B.classList.contains(d)&&o.previousElementSibling.remove();const a=o.querySelector(`.${b}`);a&&a.remove()}if(o.getAttribute("data-lcm-user-show")==="true"){if(o.classList.add(f),o.classList.remove(v),o.setAttribute("data-lcm-disabled","true"),($=o.previousElementSibling)!=null&&$.classList.contains(d)&&o.previousElementSibling.remove(),!o.querySelector(`.${b}`)){const a=document.createElement("button");a.className=b,a.textContent="Hide ad",a.onclick=p=>{p.preventDefault(),p.stopPropagation(),o.removeAttribute("data-lcm-user-show"),o.classList.add(v),W(t,i,e,n)},o.appendChild(a)}return}if(i.classList.add(f),i.setAttribute("data-lcm-disabled","true"),o.classList.add(f),o.setAttribute("data-lcm-disabled","true"),e&&(o.classList.add(v),!((m=o.previousElementSibling)!=null&&m.classList.contains(d)))){const a=document.createElement("div");a.className=d;const p=typeof chrome<"u"&&chrome.runtime?chrome.runtime.getURL("public/favicon-16x16.png"):"";let g="Vehicle";if(t.titleSelector){const c=o.querySelector(t.titleSelector);c&&c.textContent&&(g=c.textContent.trim().split(`
`)[0])}const C=o.getAttribute("data-lcm-motor")||"",r=g!=="Vehicle"?`${g}${C?` (${C})`:""}`:`${C||"Ad"} hidden`;if(n&&p){const c=document.createElement("img");c.src=p,c.alt="icon",a.appendChild(c)}const u=document.createElement("span");u.textContent=r,a.appendChild(u);const s=document.createElement("div");s.className="lcm-placeholder-line",a.appendChild(s);const h=document.createElement("div");h.className="lcm-placeholder-btn",h.textContent="Show",a.appendChild(h),a.onclick=c=>{c.stopPropagation(),o.setAttribute("data-lcm-user-show","true"),o.classList.remove(v),a.remove()},(k=o.parentNode)==null||k.insertBefore(a,o)}}function Y(t,i){var o;i.classList.remove(f),i.removeAttribute("data-lcm-disabled"),i.removeAttribute("data-lcm-user-show");const e=V(t,i)||i;e.classList.remove(f),e.classList.remove(v),e.removeAttribute("data-lcm-disabled"),e.removeAttribute("data-lcm-user-show"),(o=e.previousElementSibling)!=null&&o.classList.contains(d)&&e.previousElementSibling.remove();const n=e.querySelector(`.${b}`);n&&n.remove()}let R=0,_=null,z=null;async function J(t,i,e,n){const o=++R;U(e),F(),(_!==null&&_!==e||z!==null&&z!==n)&&(document.querySelectorAll(`.${d}`).forEach(r=>r.remove()),_!==e&&document.querySelectorAll("[data-lcm-user-show]").forEach(r=>r.removeAttribute("data-lcm-user-show"))),_=e,z=n;const B=i.map(r=>new RegExp(r.pattern,"i")),$=r=>B.some(u=>u.test(r)),m=O(window.location.href),k=m.adClasses.length>0?m.adClasses.map(r=>r.startsWith("[")||r.includes(":")||r==="article"||r==="a"?r:`.${r}`).join(", "):"a",a=Array.from(document.querySelectorAll(k)),p=new Set;a.forEach(r=>{const u=V(m,r);u&&p.add(u)});const g=Array.from(p),C=50;for(let r=0;r<g.length;r+=C){if(o!==R)return;g.slice(r,r+C).forEach(s=>{let h=(s.textContent||"")+" "+(s.getAttribute("aria-label")||"")+" "+(s.getAttribute("title")||"")+" "+(s.getAttribute("alt")||"");if(s.querySelectorAll("[aria-label], [title], [alt]").forEach(w=>{h+=" "+(w.getAttribute("aria-label")||"")+" "+(w.getAttribute("title")||"")+" "+(w.getAttribute("alt")||"")}),t&&h&&$(h)){const w=i.find(H=>new RegExp(H.pattern,"i").test(h));w&&s.setAttribute("data-lcm-motor",w.title),W(m,s,e,n)}else Y(m,s)}),await new Promise(s=>requestAnimationFrame(s))}o===R&&j()}const G=location.href;let A=L.websites,I=L.motors,M=L.hideCompletely,P=L.showPlaceholderIcon,T=L.showBadgeCount,S=L.hasConsented;function K(t,i){const e=n=>new RegExp("^"+n.replace(/\*/g,".*").replace(/\?/g,".")+"$");return t.find(n=>e(n.url).test(i))}const q=async()=>{if(!S)return;const t=K(A,G);if(!t)return;const i=t.active?I.filter(n=>n.active):[];await J(t.active&&i.length>0,i,M,P);const e=document.querySelectorAll('[data-lcm-disabled="true"]').length;browser.runtime.sendMessage({action:"updateBadge",count:e,showBadgeCount:T}).catch(()=>{})},Q=X(q,300);let y=null;function D(){y&&y.disconnect(),y=new MutationObserver(Q),y.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-lcm-disabled","aria-label","title","alt"]})}browser.runtime.onMessage.addListener((t,i,e)=>{if(t.websites)if(Array.isArray(t.websites)&&t.websites.length===1){const n=t.websites[0];A=A.map(o=>o.title===n.title?n:o)}else Array.isArray(t.websites)&&(A=t.websites);if(t.motors&&(I=t.motors),t.hideCompletely!==void 0&&(M=t.hideCompletely),t.showPlaceholderIcon!==void 0&&(P=t.showPlaceholderIcon),t.showBadgeCount!==void 0&&(T=t.showBadgeCount),t.hasConsented!==void 0&&(S=t.hasConsented),t.action==="getHiddenCount"){const n=document.querySelectorAll('[data-lcm-disabled="true"]').length;e({status:"received",count:n});return}q(),e({status:"received"})});browser.storage.onChanged.addListener((t,i)=>{i==="sync"&&(t.websites&&(A=t.websites.newValue),t.motors&&(I=t.motors.newValue),t.hideCompletely&&(M=t.hideCompletely.newValue),t.showPlaceholderIcon&&(P=t.showPlaceholderIcon.newValue),t.showBadgeCount&&(T=t.showBadgeCount.newValue),t.hasConsented&&(S=t.hasConsented.newValue,S?D():y&&y.disconnect()),q())});function X(t,i){let e=null;return(...n)=>{e&&clearTimeout(e),e=window.setTimeout(()=>t(...n),i)}}function Z(){browser.storage.sync.get(["websites","motors","hideCompletely","showPlaceholderIcon","showBadgeCount","hasConsented"],t=>{t.websites&&(A=t.websites),t.motors&&(I=t.motors),t.hideCompletely!==void 0&&(M=t.hideCompletely),t.showPlaceholderIcon!==void 0&&(P=t.showPlaceholderIcon),t.showBadgeCount!==void 0&&(T=t.showBadgeCount),t.hasConsented!==void 0&&(S=t.hasConsented),S&&(q(),D())})}Z();
