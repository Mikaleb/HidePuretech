import{i as L}from"./initialState-CBmGj4K7.js";var r=(t=>(t.LeBonCoin="LeBonCoin",t.AutoSphere="AutoSphere",t.LaCentrale="LaCentrale",t.AramisAuto="AramisAuto",t))(r||{});const l="hp-disabled",b="hp-loading-spinner";function k(){if(document.getElementById("hp-style"))return;const t=document.createElement("style");if(t.id="hp-style",t.textContent=`
    .${l}, [data-hp-disabled="true"] {
      opacity: 0.35 !important;
      filter: grayscale(100%) !important;
      pointer-events: none !important;
    }
    .${l} *, [data-hp-disabled="true"] * {
      text-decoration: line-through !important;
    }
    #${b} {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 24px;
      height: 24px;
      border: 3px solid rgba(0,0,0,0.1);
      border-radius: 50%;
      border-top-color: #3498db;
      animation: hp-spin 0.8s linear infinite;
      z-index: 999999;
      pointer-events: none;
      background: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      display: none;
    }
    @keyframes hp-spin {
      to { transform: rotate(360deg); }
    }
  `,document.head.appendChild(t),!document.getElementById(b)){const e=document.createElement("div");e.id=b,document.body.appendChild(e)}}function T(){const t=document.getElementById(b);t&&(t.style.display="block")}function B(){const t=document.getElementById(b);t&&(t.style.display="none")}function M(t){return t.includes("lacentrale")?new u(r.LaCentrale):t.includes("aramisauto")?new u(r.AramisAuto):t.includes("leboncoin")?new u(r.LeBonCoin):t.includes("autosphere")?new u(r.AutoSphere):new u(r.LaCentrale)}class u{constructor(e,i=[],n=[]){switch(this.name=e,this.parentClasses=i,this.adClasses=n,e){case r.LeBonCoin:this.parentClasses=["li"],this.adClasses=['[data-test-id="adcard-title"]',"a","article"];break;case r.LaCentrale:this.parentClasses=["searchCard","listingContainer","searchCardContainer"],this.adClasses=['[data-testid*="vehicleCard"]',"lien-fiche","link_veh"];break;case r.AutoSphere:this.parentClasses=["thumbnail_vehicle","fiche-synth"];break;case r.AramisAuto:this.parentClasses=[];break;default:this.parentClasses=[],this.adClasses=[]}}}function C(t,e){if(t.parentClasses.length===0)return null;const i=t.parentClasses.map(n=>n.startsWith("[")||n.includes(":")||n==="li"||n==="article"?n:`.${n}`).join(", ");return e.closest(i)}function W(t,e){if(!(e instanceof HTMLElement))return;e.classList.add(l),e.setAttribute("data-hp-disabled","true");const i=C(t,e);i&&(i.classList.add(l),i.setAttribute("data-hp-disabled","true"))}function I(t,e){e.classList.remove(l),e.removeAttribute("data-hp-disabled");const i=C(t,e);i&&(i.classList.remove(l),i.removeAttribute("data-hp-disabled"))}let g=0;async function P(t,e){const i=++g;k(),T();const n=e.map(s=>new RegExp(s.pattern,"i")),h=s=>n.some(d=>d.test(s)),c=M(window.location.href),S=c.adClasses.length>0?c.adClasses.map(s=>s.startsWith("[")||s.includes(":")||s==="article"||s==="a"?s:`.${s}`).join(", "):"a",E=Array.from(document.querySelectorAll(S)),y=new Set;E.forEach(s=>{const d=C(c,s);d&&y.add(d)});const v=Array.from(y),x=50;for(let s=0;s<v.length;s+=x){if(i!==g)return;v.slice(s,s+x).forEach(a=>{let w=(a.textContent||"")+" "+(a.getAttribute("aria-label")||"")+" "+(a.getAttribute("title")||"")+" "+(a.getAttribute("alt")||"");a.querySelectorAll("[aria-label], [title], [alt]").forEach(A=>{w+=" "+(A.getAttribute("aria-label")||"")+" "+(A.getAttribute("title")||"")+" "+(A.getAttribute("alt")||"")}),t&&w&&h(w)?W(c,a):I(c,a)}),await new Promise(a=>requestAnimationFrame(a))}i===g&&B()}const _=location.href;let o=L.websites,f=L.motors;function $(t,e){const i=n=>new RegExp("^"+n.replace(/\*/g,".*").replace(/\?/g,".")+"$");return t.find(n=>i(n.url).test(e))}const m=async()=>{const t=$(o,_);if(!t)return;const e=t.active?f.filter(i=>i.active):[];await P(t.active&&e.length>0,e)},R=q(m,300);let p=null;function j(){p&&p.disconnect(),p=new MutationObserver(R),p.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-hp-disabled","aria-label","title","alt"]})}browser.runtime.onMessage.addListener((t,e,i)=>{if(t.websites)if(Array.isArray(t.websites)&&t.websites.length===1){const n=t.websites[0];o=o.map(h=>h.title===n.title?n:h)}else Array.isArray(t.websites)&&(o=t.websites);t.motors&&(f=t.motors),m(),i({status:"received"})});browser.storage.onChanged.addListener((t,e)=>{e==="sync"&&(t.websites&&(o=t.websites.newValue),t.motors&&(f=t.motors.newValue),m())});function q(t,e){let i=null;return(...n)=>{i&&clearTimeout(i),i=window.setTimeout(()=>t(...n),e)}}function F(){browser.storage.sync.get(["websites","motors"],t=>{t.websites&&(o=t.websites),t.motors&&(f=t.motors),m(),j()})}F();
