import{i as k}from"./initialState-CVqLASu8.js";const u="hp-disabled",y="hp-loading-spinner",w="hp-hide-completely",c="hp-hidden-placeholder",h="hp-rehide-btn",T="hp-style";function N(t){if(document.getElementById(T)){const e=document.getElementById(T);e&&e.remove()}const i=document.createElement("style");if(i.id=T,i.textContent=`
    .${u}, [data-hp-disabled="true"] {
      opacity: 0.35 !important;
      filter: grayscale(100%) !important;
      pointer-events: none !important;
    }
    .${u} *, [data-hp-disabled="true"] * {
      text-decoration: line-through !important;
    }
  `,t&&(i.textContent+=`
      .${w}:not([data-hp-user-show="true"]) {
        display: none !important;
      }
    `),i.textContent+=`
    .${c} {
      display: flex !important;
      align-items: center !important;
      height: 28px !important;
      padding: 0 12px !important;
      margin: 8px 0 !important;
      background: rgba(242, 69, 53, 0.03) !important;
      border: 1px dashed rgba(242, 69, 53, 0.3) !important;
      border-radius: 6px !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
      color: #666 !important;
      font-size: 11px !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      user-select: none !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .${c}:hover {
      background: rgba(242, 69, 53, 0.08) !important;
      border-color: rgba(242, 69, 53, 0.5) !important;
    }
    .${c} img {
      width: 14px !important;
      height: 14px !important;
      margin-right: 8px !important;
      opacity: 0.7 !important;
    }
    .hp-placeholder-line {
      flex-grow: 1 !important;
      height: 1px !important;
      background: linear-gradient(90deg, rgba(242, 69, 53, 0.2) 0%, rgba(242, 69, 53, 0) 100%) !important;
      margin: 0 12px !important;
    }
    .hp-placeholder-btn {
      color: #f24535 !important;
      font-weight: 600 !important;
      text-transform: uppercase !important;
      letter-spacing: 0.5px !important;
      font-size: 10px !important;
      padding: 2px 6px !important;
      border-radius: 4px !important;
    }
    .hp-placeholder-btn:hover {
      background: rgba(242, 69, 53, 0.1) !important;
    }
    .${h} {
      position: absolute !important;
      top: 8px !important;
      right: 8px !important;
      z-index: 9999 !important;
      background: #f24535 !important;
      color: white !important;
      padding: 4px 12px !important;
      border-radius: 6px !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      cursor: pointer !important;
      border: none !important;
      box-shadow: 0 4px 12px rgba(242, 69, 53, 0.3) !important;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
      opacity: 0 !important;
      pointer-events: none !important;
      text-transform: uppercase !important;
      letter-spacing: 0.5px !important;
    }
    /* Revealed state aesthetic */
    [data-hp-user-show="true"] {
      position: relative !important;
      opacity: 0.8 !important;
      filter: grayscale(30%) !important;
      background: rgba(242, 69, 53, 0.04) !important;
      border: 2px dashed rgba(242, 69, 53, 0.3) !important;
      border-radius: 12px !important;
      pointer-events: auto !important;
      transition: all 0.3s ease !important;
    }
    [data-hp-user-show="true"] * {
      text-decoration: none !important;
    }
    [data-hp-user-show="true"] .${h} {
      opacity: 0.7 !important;
      pointer-events: auto !important;
    }
    [data-hp-user-show="true"]:hover .${h} {
      opacity: 1 !important;
    }
    .${h}:hover {
      background: #d43224 !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 6px 16px rgba(242, 69, 53, 0.4) !important;
    }
    #${y} {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 24px;
      height: 24px;
      border: 3px solid rgba(0,0,0,0.1);
      border-radius: 50%;
      border-top-color: #3498db;
      animation: hp-spin 0.8s linear infinite;
      z-index: 999999;
      pointer-events: none;
      background: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      display: none;
    }
    @keyframes hp-spin {
      to { transform: rotate(360deg); }
    }
  `,document.head.appendChild(i),!document.getElementById(y)){const e=document.createElement("div");e.id=y,document.body.appendChild(e)}}function W(){const t=document.getElementById(y);t&&(t.style.display="block")}function D(){const t=document.getElementById(y);t&&(t.style.display="none")}var p=(t=>(t.LeBonCoin="LeBonCoin",t.AutoSphere="AutoSphere",t.LaCentrale="LaCentrale",t.AramisAuto="AramisAuto",t))(p||{});class v{constructor(i,e=[],o=[],r=""){switch(this.name=i,this.parentClasses=e,this.adClasses=o,this.titleSelector=r,i){case p.LeBonCoin:this.parentClasses=["li"],this.adClasses=['[data-test-id="adcard-title"]',"a","article"],this.titleSelector='[data-test-id="adcard-title"]';break;case p.LaCentrale:this.parentClasses=["searchCard","listingContainer","searchCardContainer"],this.adClasses=['[data-testid*="vehicleCard"]',"lien-fiche","link_veh"],this.titleSelector='h2[class*="title"], h2[class*="vehiclecardV2_title"], h3[class*="title"], [class*="searchCard__title"]';break;case p.AutoSphere:this.parentClasses=["thumbnail_vehicle","fiche-synth"],this.titleSelector=".title, h2, h3";break;case p.AramisAuto:this.parentClasses=["vehicle-card"],this.titleSelector=".vehicle-card__title, h3";break;default:this.parentClasses=[],this.adClasses=[],this.titleSelector=""}}}function V(t){return t.includes("lacentrale")?new v(p.LaCentrale):t.includes("aramisauto")?new v(p.AramisAuto):t.includes("leboncoin")?new v(p.LeBonCoin):t.includes("autosphere")?new v(p.AutoSphere):new v(p.LaCentrale)}function q(t,i){if(t.parentClasses.length===0)return null;const e=t.parentClasses.map(o=>o.startsWith("[")||o.includes(":")||o==="li"||o==="article"?o:`.${o}`).join(", ");return i.closest(e)}function z(t,i,e,o){var A,C,d,S;const r=q(t,i)||i;if(!e){(A=r.previousElementSibling)!=null&&A.classList.contains(c)&&r.previousElementSibling.remove();const a=r.querySelector(`.${h}`);a&&a.remove()}if(r.getAttribute("data-hp-user-show")==="true"){if(r.classList.add(u),r.classList.remove(w),r.setAttribute("data-hp-disabled","true"),(C=r.previousElementSibling)!=null&&C.classList.contains(c)&&r.previousElementSibling.remove(),!r.querySelector(`.${h}`)){const a=document.createElement("button");a.className=h,a.textContent="Hide ad",a.onclick=m=>{m.preventDefault(),m.stopPropagation(),r.removeAttribute("data-hp-user-show"),r.classList.add(w),z(t,i,e,o)},r.appendChild(a)}return}if(i.classList.add(u),i.setAttribute("data-hp-disabled","true"),r.classList.add(u),r.setAttribute("data-hp-disabled","true"),e&&(r.classList.add(w),!((d=r.previousElementSibling)!=null&&d.classList.contains(c)))){const a=document.createElement("div");a.className=c;const m=typeof chrome<"u"&&chrome.runtime?chrome.runtime.getURL("public/favicon-16x16.png"):"";let b="Vehicle";if(t.titleSelector){const s=r.querySelector(t.titleSelector);s&&s.textContent&&(b=s.textContent.trim().split(`
`)[0])}const f=r.getAttribute("data-hp-motor")||"",n=b!=="Vehicle"?`${b}${f?` (${f})`:""}`:`${f||"Ad"} hidden`;a.innerHTML=`
        ${o?`<img src="${m}" alt="icon">`:""}
        <span>${n}</span>
        <div class="hp-placeholder-line"></div>
        <div class="hp-placeholder-btn">Show</div>
      `,a.onclick=s=>{s.stopPropagation(),r.setAttribute("data-hp-user-show","true"),r.classList.remove(w),a.remove()},(S=r.parentNode)==null||S.insertBefore(a,r)}}function U(t,i){var r;i.classList.remove(u),i.removeAttribute("data-hp-disabled"),i.removeAttribute("data-hp-user-show");const e=q(t,i)||i;e.classList.remove(u),e.classList.remove(w),e.removeAttribute("data-hp-disabled"),e.removeAttribute("data-hp-user-show"),(r=e.previousElementSibling)!=null&&r.classList.contains(c)&&e.previousElementSibling.remove();const o=e.querySelector(`.${h}`);o&&o.remove()}let H=0,E=null,R=null;async function F(t,i,e,o){const r=++H;N(e),W(),(E!==null&&E!==e||R!==null&&R!==o)&&(document.querySelectorAll(`.${c}`).forEach(n=>n.remove()),E!==e&&document.querySelectorAll("[data-hp-user-show]").forEach(n=>n.removeAttribute("data-hp-user-show"))),E=e,R=o;const A=i.map(n=>new RegExp(n.pattern,"i")),C=n=>A.some(s=>s.test(n)),d=V(window.location.href),S=d.adClasses.length>0?d.adClasses.map(n=>n.startsWith("[")||n.includes(":")||n==="article"||n==="a"?n:`.${n}`).join(", "):"a",a=Array.from(document.querySelectorAll(S)),m=new Set;a.forEach(n=>{const s=q(d,n);s&&m.add(s)});const b=Array.from(m),f=50;for(let n=0;n<b.length;n+=f){if(r!==H)return;b.slice(n,n+f).forEach(l=>{let L=(l.textContent||"")+" "+(l.getAttribute("aria-label")||"")+" "+(l.getAttribute("title")||"")+" "+(l.getAttribute("alt")||"");if(l.querySelectorAll("[aria-label], [title], [alt]").forEach(g=>{L+=" "+(g.getAttribute("aria-label")||"")+" "+(g.getAttribute("title")||"")+" "+(g.getAttribute("alt")||"")}),t&&L&&C(L)){const g=i.find(M=>new RegExp(M.pattern,"i").test(L));g&&l.setAttribute("data-hp-motor",g.title),z(d,l,e,o)}else U(d,l)}),await new Promise(l=>requestAnimationFrame(l))}r===H&&D()}const j=location.href;let x=k.websites,P=k.motors,_=k.hideCompletely,I=k.showPlaceholderIcon;function O(t,i){const e=o=>new RegExp("^"+o.replace(/\*/g,".*").replace(/\?/g,".")+"$");return t.find(o=>e(o.url).test(i))}const B=async()=>{const t=O(x,j);if(!t)return;const i=t.active?P.filter(e=>e.active):[];await F(t.active&&i.length>0,i,_,I)},Y=G(B,300);let $=null;function J(){$&&$.disconnect(),$=new MutationObserver(Y),$.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-hp-disabled","aria-label","title","alt"]})}browser.runtime.onMessage.addListener((t,i,e)=>{if(t.websites)if(Array.isArray(t.websites)&&t.websites.length===1){const o=t.websites[0];x=x.map(r=>r.title===o.title?o:r)}else Array.isArray(t.websites)&&(x=t.websites);t.motors&&(P=t.motors),t.hideCompletely!==void 0&&(_=t.hideCompletely),t.showPlaceholderIcon!==void 0&&(I=t.showPlaceholderIcon),B(),e({status:"received"})});browser.storage.onChanged.addListener((t,i)=>{i==="sync"&&(t.websites&&(x=t.websites.newValue),t.motors&&(P=t.motors.newValue),t.hideCompletely&&(_=t.hideCompletely.newValue),t.showPlaceholderIcon&&(I=t.showPlaceholderIcon.newValue),B())});function G(t,i){let e=null;return(...o)=>{e&&clearTimeout(e),e=window.setTimeout(()=>t(...o),i)}}function K(){browser.storage.sync.get(["websites","motors","hideCompletely","showPlaceholderIcon"],t=>{t.websites&&(x=t.websites),t.motors&&(P=t.motors),t.hideCompletely!==void 0&&(_=t.hideCompletely),t.showPlaceholderIcon!==void 0&&(I=t.showPlaceholderIcon),B(),J()})}K();
